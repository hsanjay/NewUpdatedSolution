#!/bin/sh

if [ $ftp_server = "yes" ]; then
  /etc/rc.d/init.d/vsftpd start
fi