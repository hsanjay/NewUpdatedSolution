#!/bin/sh
# Import global conf 
. $global_conf

set -e

#To support ubuntu java bins
export PATH=$PATH:/usr/java/default/bin

mkdir -p $install_path
java -Dsqlfire.installer.directory="$install_path" -jar "$SQLFire10_Installer"
 
cd $install_path/*SQLFire*

mkdir server1
./bin/sqlf server start -dir=server1 -client-port=$client_port -mcast-port=$multicast_port

            