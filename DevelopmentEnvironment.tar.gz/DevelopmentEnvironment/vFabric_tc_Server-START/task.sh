#!/bin/sh
# vFabric ApplicationDirector START script for vFabric tc Server

# From ApplicationDirector - Import and source global configuration
. $global_conf

# This script simply starts the tc Server instance created in the tcserver-config.sh sample script. 

set -e

export PATH=$PATH:/usr/sbin:/sbin:/usr/bin:/bin
export HOME=/root
export tcserver_home=${tcserver_home:="/opt/vmware/vfabric-tc-server-standard"}

export JAVA_HOME=${java_home:="/usr"}

if [ -f ${tcserver_home}/${instance_name}/bin/tcruntime-ctl.sh ]; then
    $service_start
    IS_RUNNING=`$instance_dir/bin/tcruntime-ctl.sh status | grep Status | awk -F: '{ print $2 }'`
    if [[ "${IS_RUNNING}" == *"NOT RUNNING"* ]]; then
        echo "ERROR: ${tcserver_home}/${instance_name} is NOT RUNNING."
        echo "Please check the logs in ${tcserver_home}/${instance_name}/logs for more information"
        exit 1
    else
        echo "COMPLETED: The status of your new tc Server instance is: ${IS_RUNNING}"
    fi
fi
